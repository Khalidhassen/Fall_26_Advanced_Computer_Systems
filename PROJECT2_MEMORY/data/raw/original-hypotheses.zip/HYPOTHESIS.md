The Access latency should increase as the working set exceeds each cache's capacity and Sequential access should receive higher bandwidth than random access.



Increasing competing memory traffic should eventually stop improving bandwidth while latency continues rising.



Larger pages may reduce address-translation overhead for some access patterns.


## Loaded-latency prediction � 2026-10-20T12:32:13.1527311-04:00
AI-assisted prediction recorded before this collection:
Reducing the delay between memory requests should increase bandwidth
until it approaches saturation. Beyond that region, latency should
continue increasing while bandwidth gains become smaller.

## Performance-plan loaded latency � 2026-10-20T12:37:43.4735150-04:00
AI-assisted prediction recorded before collection:
Latency should rise as memory traffic increases, with smaller bandwidth
gains at higher loads. The Performance plan may change the results;
the direction and size of that change are not assumed.
