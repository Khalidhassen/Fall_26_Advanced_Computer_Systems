
## Page-size prediction � 2026-10-20T13:09:07.3848212-04:00
AI-assisted prediction before collection:
Large pages may reduce address-translation overhead for this random-access
test. A latency difference alone would not prove a particular TLB miss rate.

## Page-locality sweep � 2026-10-20T13:21:04.4510724-04:00
AI-assisted prediction after the pilot, before this full sweep:
Spreading the same number of cache-line nodes across more 4 KiB pages
may increase dependent-load time. Cache behavior can also contribute;
this experiment does not directly count TLB misses.

## Access-pattern latency sweep � 2026-10-20T13:27:17.4178378-04:00
AI-assisted prediction after earlier experiments, before this collection:
Sequential access may report lower latency because prefetchers remain
enabled. Increasing spacing may reduce that benefit. MLC randomization
uses bounded blocks, so it is not a globally random pointer chain.

## Mixed-traffic latency � 2026-10-20T13:30:43.9937830-04:00
AI-assisted prediction before this collection:
Changing background read/write traffic may change both bandwidth and
read-probe latency. Non-temporal writes use a different store policy,
so their results cannot isolate read/write ratio alone.
